United Open-Libraries of Sound ( UOS ).

UOS unify the best open-source audio libraries.

With UOS you can :

. Listen to mp3, ogg, wav, flac,... audio files.
. With 16, 32 or float 32 bit resolution.
. Record all type of input into file.
. Add DSP effects and filters, how many you want and record it.
. Listen to multiple input and output.

UOS use PortAudio, SndFile and Mpg123 audio libraries ( other libraries are welcome... )

Fred van Stappen
fiens@hotmail.com

