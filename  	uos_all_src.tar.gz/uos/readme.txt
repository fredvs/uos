UOS : United OpenLib of Sound. UOS unifies the best open-source audio libraries.

With UOS you can:

. Listen to mp3, ogg, wav, flac,... audio files.

. With 16, 32 or float 32 bit resolution.

. Record all types of input into file.

. Add DSP effects and filters, however many you want and record it.

. Listen to multiple inputs and outputs.

UOS uses the PortAudio, SndFile and Mpg123 audio libraries.

Included in the package:
. Examples.
. Binary libraries for Linux 32/64, Windows 32/64, Mac OSX 32. 

Fred van Stappen
fiens@hotmail.com

